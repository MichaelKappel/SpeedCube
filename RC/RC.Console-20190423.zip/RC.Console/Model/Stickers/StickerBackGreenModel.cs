﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerBackGreenModel : StickerGreenModel
    {
        public StickerBackGreenModel() : base()
        {

        }
    }
}
