﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontBlueModel : StickerBlueModel
    {
        public StickerFrontBlueModel() : base()
        {

        }
    }
}
