﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackSouthWestRedModel : StickerRedModel
    {
        public StickerBackSouthWestRedModel() : base()
        {

        }
    }
}