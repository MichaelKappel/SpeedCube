﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerFrontEastOrangeModel : StickerOrangeModel
    {
        public StickerFrontEastOrangeModel() : base()
        {

        }
    }
}