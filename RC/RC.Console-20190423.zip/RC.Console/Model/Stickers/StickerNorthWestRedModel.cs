﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerNorthWestRedModel : StickerRedModel
    {
        public StickerNorthWestRedModel() : base()
        {

        }
    }
}
