﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontNorthEastBlueModel : StickerBlueModel
    {
        public StickerFrontNorthEastBlueModel() : base()
        {

        }
    }
}