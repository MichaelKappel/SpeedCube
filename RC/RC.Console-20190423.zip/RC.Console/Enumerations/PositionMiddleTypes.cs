﻿namespace RC.Enumerations
{
    public enum PositionMiddleTypes
    {
        North,
        South,
        Front,
        Back,
        East,
        West
    }
}
