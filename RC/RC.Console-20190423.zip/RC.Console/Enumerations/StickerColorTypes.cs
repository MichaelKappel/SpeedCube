﻿namespace RC.Enumerations
{
    public enum StickerColorTypes
    {
        None,
        White,
        Yellow,
        Green,
        Red,
        Blue,
        Orange
    }
}
