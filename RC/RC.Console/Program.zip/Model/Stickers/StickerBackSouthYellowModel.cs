﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackSouthYellowModel : StickerYellowModel
    {
        public StickerBackSouthYellowModel() : base()
        {

        }
    }
}