﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontNorthWhiteModel : StickerWhiteModel
    {
        public StickerFrontNorthWhiteModel() : base()
        {

        }
    }
}
