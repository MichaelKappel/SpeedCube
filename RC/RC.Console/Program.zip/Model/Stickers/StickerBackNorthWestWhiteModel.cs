﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackNorthWestWhiteModel : StickerWhiteModel
    {
        public StickerBackNorthWestWhiteModel() : base()
        {

        }
    }
}