﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerWestRedModel : StickerRedModel
    {
        public StickerWestRedModel() : base()
        {

        }
    }
}
