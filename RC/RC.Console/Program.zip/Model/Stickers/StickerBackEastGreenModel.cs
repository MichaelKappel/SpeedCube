﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackEastGreenModel : StickerGreenModel
    {
        public StickerBackEastGreenModel() : base()
        {

        }
    }

}