﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackNorthWestGreenModel : StickerGreenModel
    {
        public StickerBackNorthWestGreenModel() : base()
        {

        }
    }
}