﻿using RC.Enumerations;
using RC.Model.Pieces;
using RC.Model.Slots;
using System.Linq;

namespace RC.Model
{
    public class CubeModel
    {
        public CubeModel()
        {
            var frontNorthPiece = new PieceFrontNorthModel();
            var frontEastPiece = new PieceFrontEastModel();
            var frontSouthPiece = new PieceFrontSouthModel();
            var frontWestPiece = new PieceFrontWestModel();

            var frontNorthEastPiece = new PieceFrontNorthEastModel();
            var frontSouthEastPiece = new PieceFrontSouthEastModel();
            var frontSouthWestPiece = new PieceFrontSouthWestModel();
            var frontNorthWestPiece = new PieceFrontNorthWestModel();

            var northEastPiece = new PieceNorthEastModel();
            var southEastPiece = new PieceSouthEastModel();
            var southWestPiece = new PieceSouthWestModel();
            var northWestPiece = new PieceNorthWestModel();

            var backNorthPiece = new PieceBackNorthModel();
            var backEastPiece = new PieceBackEastModel();
            var backSouthPiece = new PieceBackSouthModel();
            var backWestPiece = new PieceBackWestModel();

            var backNorthEastPiece = new PieceBackNorthEastModel();
            var backSouthEastPiece = new PieceBackSouthEastModel();
            var backSouthWestPiece = new PieceBackSouthWestModel();
            var backNorthWestPiece = new PieceBackNorthWestModel();

            this.FrontNorth.Piece = frontNorthPiece;
            this.FrontEast.Piece = frontEastPiece;
            this.FrontSouth.Piece = frontSouthPiece;
            this.FrontWest.Piece = frontWestPiece;


            this.FrontNorthEast.Piece = frontNorthEastPiece;
            this.FrontSouthEast.Piece = frontSouthEastPiece;
            this.FrontSouthWest.Piece = frontSouthWestPiece;
            this.FrontNorthWest.Piece = frontNorthWestPiece;


            this.NorthEast.Piece = northEastPiece;
            this.SouthEast.Piece = southEastPiece;
            this.SouthWest.Piece = southWestPiece;
            this.NorthWest.Piece = northWestPiece;

            this.BackNorth.Piece = backNorthPiece;
            this.BackEast.Piece = backEastPiece;
            this.BackSouth.Piece = backSouthPiece;
            this.BackWest.Piece = backWestPiece;

            this.BackNorthEast.Piece = backNorthEastPiece;
            this.BackSouthEast.Piece = backSouthEastPiece;
            this.BackSouthWest.Piece = backSouthWestPiece;
            this.BackNorthWest.Piece = backNorthWestPiece;


            //********************************************************
            //      STICKERS
            //********************************************************

            this.NorthEast.StickerNorth = northEastPiece.StickerNorthEastWhite;
            this.NorthEast.StickerEast = northEastPiece.StickerNorthEastOrange;

            this.NorthWest.StickerNorth = northWestPiece.StickerNorthWestWhite;
            this.NorthWest.StickerWest = northWestPiece.StickerNorthWestRed;

            this.FrontNorth.StickerFront = frontNorthPiece.StickerFrontNorthBlue;
            this.FrontNorth.StickerNorth = frontNorthPiece.StickerFrontNorthWhite;

            this.BackNorth.StickerBack = backNorthPiece.StickerBackNorthGreen;
            this.BackNorth.StickerNorth = backNorthPiece.StickerBackNorthWhite;


            this.SouthEast.StickerSouth = southEastPiece.StickerSouthEastYellow;
            this.SouthEast.StickerEast = southEastPiece.StickerSouthEastOrange;

            this.SouthWest.StickerSouth = southWestPiece.StickerSouthWestYellow;
            this.SouthWest.StickerWest = southWestPiece.StickerSouthWestRed;

            this.FrontSouth.StickerFront = frontSouthPiece.StickerFrontSouthBlue;
            this.FrontSouth.StickerSouth = frontSouthPiece.StickerFrontSouthYellow;

            this.BackSouth.StickerBack = backSouthPiece.StickerBackSouthGreen;
            this.BackSouth.StickerSouth = backSouthPiece.StickerBackSouthYellow;


            this.FrontEast.StickerFront = frontEastPiece.StickerFrontEastBlue;
            this.FrontEast.StickerEast = frontEastPiece.StickerFrontEastOrange;

            this.FrontWest.StickerFront = frontWestPiece.StickerFrontWestBlue;
            this.FrontWest.StickerWest = frontWestPiece.StickerFrontWestRed;

            this.BackEast.StickerEast = backEastPiece.StickerBackEastOrange;
            this.BackEast.StickerBack = backEastPiece.StickerBackEastGreen;

            this.BackWest.StickerBack = backWestPiece.StickerBackWestGreen;
            this.BackWest.StickerWest = backWestPiece.StickerBackWestRed;


            this.FrontNorthEast.StickerFront = frontNorthEastPiece.StickerFrontNorthEastBlue;
            this.FrontNorthEast.StickerNorth = frontNorthEastPiece.StickerFrontNorthEastWhite;
            this.FrontNorthEast.StickerEast = frontNorthEastPiece.StickerFrontNorthEastOrange;

            this.FrontSouthEast.StickerFront = frontSouthEastPiece.StickerFrontSouthEastBlue;
            this.FrontSouthEast.StickerSouth = frontSouthEastPiece.StickerFrontSouthEastYellow;
            this.FrontSouthEast.StickerEast = frontSouthEastPiece.StickerFrontSouthEastOrange;

            this.FrontSouthWest.StickerFront = frontSouthWestPiece.StickerFrontSouthWestBlue;
            this.FrontSouthWest.StickerSouth = frontSouthWestPiece.StickerFrontSouthWestYellow;
            this.FrontSouthWest.StickerWest = frontSouthWestPiece.StickerFrontSouthWestRed;

            this.FrontNorthWest.StickerFront = frontNorthWestPiece.StickerFrontNorthWestBlue;
            this.FrontNorthWest.StickerNorth = frontNorthWestPiece.StickerFrontNorthWestWhite;
            this.FrontNorthWest.StickerWest = frontNorthWestPiece.StickerFrontNorthWestRed;


            this.BackNorthEast.StickerBack = backNorthEastPiece.StickerBackNorthEastGreen;
            this.BackNorthEast.StickerNorth = backNorthEastPiece.StickerBackNorthEastWhite;
            this.BackNorthEast.StickerEast = backNorthEastPiece.StickerBackNorthEastOrange;

            this.BackSouthEast.StickerBack = backSouthEastPiece.StickerBackSouthEastGreen;
            this.BackSouthEast.StickerSouth = backSouthEastPiece.StickerBackSouthEastYellow;
            this.BackSouthEast.StickerEast = backSouthEastPiece.StickerBackSouthEastOrange;

            this.BackSouthWest.StickerBack = backSouthWestPiece.StickerBackSouthWestGreen;
            this.BackSouthWest.StickerSouth = backSouthWestPiece.StickerBackSouthWestYellow;
            this.BackSouthWest.StickerWest = backSouthWestPiece.StickerBackSouthWestRed;

            this.BackNorthWest.StickerBack = backNorthWestPiece.StickerBackNorthWestGreen;
            this.BackNorthWest.StickerNorth = backNorthWestPiece.StickerBackNorthWestWhite;
            this.BackNorthWest.StickerWest = backNorthWestPiece.StickerBackNorthWestRed;
        }

        //Side
        public PieceNorthModel North { get; } = new PieceNorthModel();
        public PieceSouthModel South { get; } = new PieceSouthModel();
        public PieceWestModel West { get; } = new PieceWestModel();
        public PieceEastModel East { get; } = new PieceEastModel();
        public PieceFrontModel Front { get; } = new PieceFrontModel();
        public PieceBackModel Back { get; } = new PieceBackModel();

        //Front
        public SlotFrontNorthModel FrontNorth { get; } = new SlotFrontNorthModel();
        public SlotFrontNorthEastModel FrontNorthEast { get; } = new SlotFrontNorthEastModel();
        public SlotFrontEastModel FrontEast { get; } = new SlotFrontEastModel();
        public SlotFrontSouthEastModel FrontSouthEast { get; } = new SlotFrontSouthEastModel();
        public SlotFrontSouthModel FrontSouth { get; } = new SlotFrontSouthModel();
        public SlotFrontSouthWestModel FrontSouthWest { get; } = new SlotFrontSouthWestModel();
        public SlotFrontWestModel FrontWest { get; } = new SlotFrontWestModel();
        public SlotFrontNorthWestModel FrontNorthWest { get; } = new SlotFrontNorthWestModel();

        //Sides
        public SlotNorthEastModel NorthEast { get; } = new SlotNorthEastModel();
        public SlotSouthEastModel SouthEast { get; } = new SlotSouthEastModel();
        public SlotSouthWestModel SouthWest { get; } = new SlotSouthWestModel();
        public SlotNorthWestModel NorthWest { get; } = new SlotNorthWestModel();

        //Back
        public SlotBackNorthModel BackNorth { get; } = new SlotBackNorthModel();
        public SlotBackNorthEastModel BackNorthEast { get; } = new SlotBackNorthEastModel();
        public SlotBackEastModel BackEast { get; } = new SlotBackEastModel();
        public SlotBackSouthEastModel BackSouthEast { get; } = new SlotBackSouthEastModel();
        public SlotBackSouthModel BackSouth { get; } = new SlotBackSouthModel();
        public SlotBackSouthWestModel BackSouthWest { get; } = new SlotBackSouthWestModel();
        public SlotBackWestModel BackWest { get; } = new SlotBackWestModel();
        public SlotBackNorthWestModel BackNorthWest { get; } = new SlotBackNorthWestModel();

    }
}
