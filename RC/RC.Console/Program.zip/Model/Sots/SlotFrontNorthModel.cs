﻿using RC.Enumerations;
using RC.Interfaces;
using RC.Model;

namespace RC.Model.Slots
{

    public class SlotFrontNorthModel : SlotSideModelBase, IStickerNorth, IStickerFront
    {
        public SlotFrontNorthModel()
        {

        }

        public override PositionSideTypes PositionSideType { get; protected set; } = PositionSideTypes.FrontNorth;

        public StickerModelBase StickerFront { get; set; }
        public StickerModelBase StickerNorth { get; set; }
    }

}