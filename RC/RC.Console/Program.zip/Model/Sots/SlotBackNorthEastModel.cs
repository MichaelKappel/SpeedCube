﻿using RC.Enumerations;
using RC.Interfaces;
using RC.Model;
using RC.Model.Pieces;

namespace RC.Model.Slots
{

    public class SlotBackNorthEastModel : SlotCornerModelBase, IStickerNorth, IStickerBack, IStickerEast
    {
        public SlotBackNorthEastModel()
        {

        }

        public override PositionCornerTypes PositionCornerType { get; protected set; } = PositionCornerTypes.BackNorthEast;

        public StickerModelBase StickerNorth { get; set; }

        public StickerModelBase StickerBack { get; set; } 

        public StickerModelBase StickerEast{ get; set; }

    }

}