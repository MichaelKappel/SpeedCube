﻿using RC.Enumerations;
using RC.Interfaces;
using RC.Model;

namespace RC.Model.Slots
{

    public class SlotFrontNorthWestModel : SlotCornerModelBase, IStickerNorth, IStickerFront, IStickerWest
    {
        public SlotFrontNorthWestModel()
        {

        }

        public override PositionCornerTypes PositionCornerType { get; protected set; } = PositionCornerTypes.FrontNorthWest;

        public StickerModelBase StickerFront { get; set; }
        public StickerModelBase StickerNorth { get; set; }
        public StickerModelBase StickerWest { get; set; }
    }
}