﻿using RC.Enumerations;
using RC.Interfaces;
using RC.Model;
using RC.Model.Pieces;

namespace RC.Model.Slots
{

    public class SlotBackNorthModel : SlotSideModelBase, IStickerNorth, IStickerBack
    {
        public SlotBackNorthModel()
        {

        }

        public override PositionSideTypes PositionSideType { get; protected set; } = PositionSideTypes.BackNorth;

        public StickerModelBase StickerBack { get; set; }
        public StickerModelBase StickerNorth { get; set; }
    }

}