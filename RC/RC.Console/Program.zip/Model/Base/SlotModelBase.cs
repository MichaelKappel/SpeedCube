﻿using System;

namespace RC.Model
{
    public abstract class SlotModelBase
    {
        public SlotModelBase()
        {
           
        }
    }
}
