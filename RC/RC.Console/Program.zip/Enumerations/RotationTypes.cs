﻿namespace RC.Enumerations
{
    public enum RotationTypes
    {
        R0,
        R90,
        R180,
        R270
    }
}
