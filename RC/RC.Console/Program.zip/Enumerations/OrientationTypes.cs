﻿namespace RC.Enumerations
{
    public enum OrientationTypes
    {
        Up,
        Down,
        Right,
        Left,
        Front,
        Back
    }
}
