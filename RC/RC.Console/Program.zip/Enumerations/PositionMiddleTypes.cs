﻿namespace RC.Enumerations
{
    public enum PositionMiddleTypes
    {
        Front,
        Back,
        North,
        South,
        East,
        West
    }
}
