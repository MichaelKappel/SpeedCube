﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC.Enumerations;
using RC.Model;

namespace RC.Logic
{
    public class MovementLogic
    {
        public MovementLogic()
        {

        }

        public void Move(PieceCornerModelBase cornerPiece, PositionCornerTypes oldSpot, PositionCornerTypes newSpot)
        {

        }

        public void Move(PieceSideModelBase sidePiece, PositionSideTypes oldSpot, PositionSideTypes newSpot)
        {

        }
    }
}
