﻿namespace RC.Enumerations
{
    public enum PositionSideTypes
    {
        FrontNorth,
        FrontEast,
        FrontSouth,
        FrontWest,
        NorthEast,
        SouthEast,
        SouthWest,
        NorthWest,
        BackNorth,
        BackEast,
        BackSouth,
        BackWest,
    }
}
