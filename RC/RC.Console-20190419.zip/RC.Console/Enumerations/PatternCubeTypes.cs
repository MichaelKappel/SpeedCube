﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RC.Enumerations
{

    //	        A A A 
    //	        A A A 
    //	        A A A 

    //	B B B	C C C	b b b	c c c 
    //	B B B	C C C	b b b   c c c 
    //	B B B	C C C	b b b	c c c 

    //	        a a a 
    //	        a a a 
    //	        a a a
    public enum PatternCubeTypes
    {
        //****************************//
        //  White
        //****************************//

        /// <summary>
        /// A=White
        /// a=Yellow
        /// B=Red
        /// b=Orange
        /// C=Green
        /// c=Blue
        WYROGB,

        /// <summary>
        /// A=White
        /// a=Yellow
        /// B=Orange
        /// b=Red
        /// C=Blue
        /// c=Green
        WYORBG,

        /// <summary>
        /// A=White
        /// a=Yellow
        /// B=Blue
        /// b=Green
        /// C=Red
        /// c=Orange
        WYBGRO,

        /// <summary>
        /// A=White
        /// a=Yellow
        /// B=Green
        /// b=Blue
        /// C=Orange
        /// c=Red
        WYGBOR,

        //****************************//
        //  Yellow
        //****************************//

        /// <summary>
        /// A=Yellow
        /// a=White
        /// B=Red
        /// b=Orange
        /// C=Blue
        /// c=Green
        /// </summary>
        YWROBG,

        /// <summary>
        /// A=Yellow
        /// a=White
        /// B=Orange
        /// b=Red
        /// C=Green
        /// c=Blue
        /// </summary>
        YWORGB,

        /// <summary>
        /// A=Yellow
        /// a=White
        /// B=Blue
        /// b=Green
        /// C=Orange
        /// c=Red
        /// </summary>
        YWBGOR,

        /// <summary>
        /// A=Yellow
        /// a=White
        /// B=Green
        /// b=Blue
        /// C=Red
        /// c=Orange
        /// </summary>
        YWGBRO,

        //****************************//
        //  Blue
        //****************************//


        /// <summary>
        /// A=Blue
        /// a=Green
        /// B=White
        /// b=Yellow
        /// C=Orange
        /// c=Red
        /// </summary>
        BGWYOR,

        /// <summary>
        /// A=Blue
        /// a=Green
        /// B=Yellow
        /// b=White
        /// C=Red
        /// c=Orange
        /// </summary>
        BGYWRO,

        /// <summary>
        /// A=Blue
        /// a=Green
        /// B=Orange
        /// b=Red
        /// C=Yellow
        /// c=White
        /// </summary>
        BGORYW,


        /// <summary>
        /// A=Blue
        /// a=Green
        /// B=Red
        /// b=Orange
        /// C=White
        /// c=Yellow
        /// </summary>
        BGROWY,


        //****************************//
        //  Green
        //****************************//

        /// <summary>
        /// A=Green
        /// a=Blue
        /// B=White
        /// b=Yellow
        /// C=Red
        /// c=Orange
        /// </summary>
        GBWYRO,

        /// <summary>
        /// A=Green
        /// a=Blue
        /// B=Yellow
        /// b=White
        /// C=Orange
        /// c=Red 
        /// </summary>
        GBYWOR,

        /// <summary>
        /// A=Green
        /// a=Blue
        /// B=Red
        /// b=Orange
        /// C=Yellow
        /// c=White
        GBROYW,

        /// <summary>
        /// A=Green
        /// a=Blue
        /// B=Orange
        /// b=Red
        /// C=White
        /// c=Yellow
        /// </summary>
        GBORWY,

        //****************************//
        //  Red
        //****************************//

        /// <summary>
        /// A=Red
        /// a=Orange
        /// B=White
        /// b=Yellow
        /// C=Blue
        /// c=Green
        /// </summary>
        ROWYBG,

        /// <summary>
        /// A=Red
        /// a=Orange
        /// B=Yellow
        /// b=White
        /// C=Green
        /// c=Blue
        /// </summary>
        ROYWGB,

        /// <summary>
        /// A=Red
        /// a=Orange
        /// B=Blue
        /// b=Green
        /// C=Yellow
        /// c=White
        /// </summary>
        ROBGYW,

        /// <summary>
        /// A=Red
        /// a=Orange
        /// B=Green
        /// b=Blue
        /// C=Yellow
        /// c=White
        /// </summary>
        ROGBYW,

        //****************************//
        //  Orange
        //****************************//

        /// <summary>
        /// A=Orange
        /// a=Red
        /// B=White
        /// b=Yellow
        /// C=Green
        /// c=Blue
        /// </summary>
        ORWYGB,

        /// <summary>
        /// A=Orange
        /// a=Red
        /// B=Yellow
        /// b=White
        /// C=Blue
        /// c=Green
        /// </summary>
        ORYWBG,

        /// A=Orange
        /// a=Red
        /// B=Blue
        /// b=Green
        /// C=White
        /// c=Yellow
        /// </summary>
        ORBGWY,

        /// A=Red
        /// a=Orange
        /// B=Green
        /// b=Blue
        /// C=Yellow
        /// c=White
        /// </summary>
        ORGBYW

    }
}
