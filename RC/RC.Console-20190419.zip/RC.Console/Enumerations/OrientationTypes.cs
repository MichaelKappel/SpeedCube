﻿namespace RC.Enumerations
{
    public enum OrientationTypes
    {
        North,
        South,
        East,
        West,
        Front,
        Back
    }
}
