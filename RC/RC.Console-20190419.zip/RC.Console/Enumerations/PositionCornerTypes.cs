﻿namespace RC.Enumerations
{
    public enum PositionCornerTypes
    {
        FrontNorthEast,
        FrontSouthEast,
        FrontSouthWest,
        FrontNorthWest,
        BackNorthEast,
        BackSouthEast,
        BackSouthWest,
        BackNorthWest
    }
}
