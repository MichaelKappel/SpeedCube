﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontWestRedModel : StickerRedModel
    {
        public StickerFrontWestRedModel() : base()
        {

        }
    }
}
