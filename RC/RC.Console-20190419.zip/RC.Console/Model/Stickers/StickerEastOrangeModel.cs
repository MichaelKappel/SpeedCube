﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerEastOrangeModel : StickerOrangeModel
    {
        public StickerEastOrangeModel() : base()
        {

        }
    }
}
