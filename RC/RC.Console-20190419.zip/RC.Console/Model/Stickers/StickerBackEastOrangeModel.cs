﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackEastOrangeModel : StickerOrangeModel
    {
        public StickerBackEastOrangeModel() : base()
        {

        }

    }

}