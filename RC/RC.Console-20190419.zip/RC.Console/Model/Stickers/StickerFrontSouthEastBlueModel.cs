﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontSouthEastBlueModel : StickerBlueModel
    {
        public StickerFrontSouthEastBlueModel() : base()
        {

        }
    }
}
