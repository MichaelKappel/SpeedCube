﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontSouthEastYellowModel : StickerYellowModel
    {
        public StickerFrontSouthEastYellowModel() : base()
        {

        }
    }
}
