﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackNorthGreenModel : StickerGreenModel
    {
        public StickerBackNorthGreenModel() : base()
        {

        }
    }
}