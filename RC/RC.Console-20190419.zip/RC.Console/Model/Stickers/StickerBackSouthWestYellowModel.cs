﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackSouthWestYellowModel : StickerYellowModel
    {
        public StickerBackSouthWestYellowModel() : base()
        {

        }
    }
}