﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{

    public class StickerBackSouthEastYellowModel : StickerYellowModel
    {
        public StickerBackSouthEastYellowModel() : base()
        {

        }
    }
}