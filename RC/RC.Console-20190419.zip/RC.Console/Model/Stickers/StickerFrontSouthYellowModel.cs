﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerFrontSouthYellowModel : StickerYellowModel
    {
        public StickerFrontSouthYellowModel() : base()
        {

        }
    }
}
