﻿using RC.Enumerations;
using RC.Model;

namespace RC.Model.Stickers
{
    public class StickerNorthWhiteModel : StickerWhiteModel
    {
        public StickerNorthWhiteModel() : base()
        {

        }
    }
}
