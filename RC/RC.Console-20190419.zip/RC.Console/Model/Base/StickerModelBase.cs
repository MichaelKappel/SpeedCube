﻿using System.Collections.Generic;
using RC.Enumerations;

namespace RC.Model
{
    public abstract class StickerModelBase 
    {
        public StickerModelBase(StickerColorTypes stickerColorType, OrientationTypes orientationType) 
        {
            this.StickerColorType = stickerColorType;
            this.OrientationType = orientationType;
        }

        public StickerColorTypes StickerColorType
        {
            get;
            protected set;
        }

        public OrientationTypes OrientationType
        {
            get;
            set;
        }


    public override string ToString()
        {
            return this.StickerColorType.ToString();
        }
    }
}
