﻿using RC.Enumerations;
using RC.Interfaces;
using System;
using System.Linq;

namespace RC.Model
{
    public abstract class PieceSideModelBase<T> : PieceModelBase, ICloneable<T>
    {
        public PieceSideModelBase(): base()
        {

        }

        public abstract PositionSideTypes InitialSideType
        {
            get;
            protected set;
        }

        public override string ToString()
        {
            return string.Format("{0} {1}", this.InitialSideType.ToString(), base.ToString());
        }

        public abstract T Clone();
    }
}