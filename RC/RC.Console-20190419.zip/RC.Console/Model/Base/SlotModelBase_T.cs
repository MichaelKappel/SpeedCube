﻿using RC.Interfaces;

namespace RC.Model
{
    public abstract class SlotModelBase<T> : SlotModelBase, ICloneable<T> where T : PieceModelBase
    {
        public SlotModelBase()
            : base()
        {

        }

        public T Piece { get; set; }

        public T Clone()
        {
            throw new System.NotImplementedException();
        }

        public override string ToString()
        {
            return this.Piece.ToString();
        }
    }
}
