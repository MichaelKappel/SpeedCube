﻿using RC.Enumerations;
using RC.Model.Slots;
using RC.Model.Stickers;

namespace RC.Model.Pieces
{

    public class PieceEastModel : PieceMiddleModelBase
    {
        public PieceEastModel() : base()
        {
            this.Stickers.Add(this.StickerEast);
        }

        public override PositionMiddleTypes InitialMiddleType { get; protected set; } = PositionMiddleTypes.East;

        public StickerEastOrangeModel StickerEast { get; private set; } = new StickerEastOrangeModel();

        public SlotNorthEastModel SlotNorthEast { get; set; }

        public SlotFrontEastModel SlotFrontEast { get; set; }

        public SlotSouthEastModel SlotSouthEast { get; set; }

        public SlotBackEastModel SlotBackEast { get; set; }
    }

}