﻿using RC.Enumerations;
using RC.Model.Slots;
using RC.Model.Stickers;

namespace RC.Model.Pieces
{

    public class PieceNorthModel : PieceMiddleModelBase
    {
        public PieceNorthModel() : base()
        {
            this.Stickers.Add(this.StickerNorth);
        }

        public override PositionMiddleTypes InitialMiddleType { get; protected set; } = PositionMiddleTypes.North;

        public StickerNorthWhiteModel StickerNorth { get; private set; } = new StickerNorthWhiteModel();


        public SlotBackNorthModel SlotBackNorth { get; set; }

        public SlotNorthWestModel SlotNorthWest { get; set; }

        public SlotFrontNorthModel SlotFrontNorth { get; set; }

        public SlotNorthEastModel SlotNorthEast { get; set; }
    }

}