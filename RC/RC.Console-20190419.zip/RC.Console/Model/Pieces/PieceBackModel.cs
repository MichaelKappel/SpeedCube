﻿using RC.Enumerations;
using RC.Model.Slots;
using RC.Model.Stickers;

namespace RC.Model.Pieces
{

    public class PieceBackModel : PieceSideModelBase<PieceBackModel>
    {
        public PieceBackModel() : base()
        {
            this.Stickers.Add(this.StickerBack);
        }

        public override PositionMiddleTypes InitialMiddleType { get; protected set; } = PositionMiddleTypes.Back;

        public StickerBackGreenModel StickerBack { get; private set; } = new StickerBackGreenModel();


        public SlotBackNorthModel SlotBackNorth { get; set; }

        public SlotBackEastModel SlotBackEast { get; set; }

        public SlotBackSouthModel SlotBackSouth { get; set; }

        public SlotBackWestModel SlotBackWest { get; set; }
    }

}