﻿using RC.Enumerations;
using RC.Model.Slots;
using RC.Model.Stickers;

namespace RC.Model.Pieces
{

    public class PieceFrontModel : PieceMiddleModelBase
    {
        public PieceFrontModel() : base()
        {
            this.Stickers.Add(this.StickerFront);
        }

        public override PositionMiddleTypes InitialMiddleType { get; protected set; } = PositionMiddleTypes.Front;

        public StickerFrontBlueModel StickerFront { get; private set; } = new StickerFrontBlueModel();


        public SlotFrontNorthModel SlotFrontNorth { get; set; }

        public SlotFrontEastModel SlotFrontEast { get; set; }

        public SlotFrontSouthModel SlotFrontSouth { get; set; }

        public SlotFrontWestModel SlotFrontWest { get; set; }
    }

}