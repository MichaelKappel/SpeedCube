﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC.Enumerations;
using RC.Logic;

namespace RC.Model.Patterns
{
    public class PatternAdjacentResultModel: PatternResultModelBase<PatternAdjacentTypes>
    {

    }
}
